cat /lib/modules/$(uname -r)/build/.config
