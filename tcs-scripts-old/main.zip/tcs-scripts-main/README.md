# tcs-scripts
Misc. Scripts We Use

At this time, we are slowly building our library of scripts - all of which should be considered experimental until further notice.
They may work, or break your system, so we cannot take responsibility for recklessly running code without checking it first!
The scripts will, over time, provide added benefits to Fedora users, and are listed here.

- [WIP] ColorEcho (cecho):  Allows the BASH echo command to output in color quickly and easily.
- [WIP] KTools:             A set of various kernel tools.
- [WIP] RPMFusion:          Tools to install RPM Fusion.
- [WIP] 45Drives-setup:     Install tools from 45Drives.
- [WIP] FLIP:               Find Largest Installed Packages.
- [WIP] add-fcontext:       find SeLinux context.

We will plan on supporting other Linux distros in the future, such as CentOS and its successors, RHEL, elrepo, Debian, and Ubuntu.  
