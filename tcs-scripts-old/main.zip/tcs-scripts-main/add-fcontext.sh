semanage --fcontext --add --type samba_share_t /home/mediafiles
